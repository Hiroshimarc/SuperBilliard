/*
 * Ensemble des balles 
 */
package modele;

import static java.lang.Thread.sleep;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.paint.Color;
import javafx.application.Platform;
import javafx.scene.shape.Line;
import javafx.scene.shape.Path;

/**
 * Classe représentant l'ensemble des balles sur une table de billard 2017-04-09
 *
 * @author Vittorio Passuello-Dussault
 * @version 2.0
 * @see Balle
 */
public class EnsembleDeBalles extends BalleStructure {

    //Attributs
    private BalleStructure[] tabBalles = new BalleStructure[5];
    private BalleStructure balle1, balle2, balle3, balle4;
    private BalleStructure balleBlanche;
    private Color motif = Color.WHITE;
    private int nombreBallesEntrees = 0;

    //Accesseurs des attributs
    /**
     * Accesseur du tableau d'objets BalleStructure tabBalles
     *
     * @return tabBalles Objet de type BalleStructure[], tableau des balles de
     * billard (BalleStructure) du jeu
     */
    public BalleStructure[] getTabBalles() {
        return this.tabBalles;
    }

    /**
     * Accesseur de la couleur du motif distinguant les objets BalleStructure
     * des deux équipes
     *
     * @return motif Couleur du motif qui distingue les objets BalleStructure
     * des deux équipes
     */
    public Color getMotif() {
        return this.motif;
    }

    /**
     * Accesseur de balleBlanche
     *
     * @return balleBlanche Balle blanche du jeu
     */
    public BalleStructure getBalleBlanche() {
        return this.balleBlanche;
    }

    /**
     * Accesseur de balle1
     *
     * @return balle1 balle numéro 1 du jeu
     */
    public BalleStructure getBalle1() {
        return this.balle1;
    }

    /**
     * Accesseur de balle2
     *
     *
     * @return balle2 balle numéro 2 du jeu
     */
    public BalleStructure getBalle2() {
        return this.balle2;
    }

    /**
     * Accesseur de balle3
     *
     * @return balle3 balle numéro 3 du jeu
     */
    public BalleStructure getBalle3() {
        return this.balle3;
    }

    /**
     * Accesseur de balle4
     *
     * @return balle4 balle numéro 4 du jeu
     */
    public BalleStructure getBalle4() {
        return this.balle4;
    }

    //Mutateurs
    /**
     * Mutateur de l'objet tabBalles de type BalleStructure[]
     *
     * @param tabBalles Objet de type BalleStructure[] à assigner à l'attribut
     * tabBalles
     */
    public void setTabBalles(BalleStructure[] tabBalles) {
        this.tabBalles = tabBalles;
    }

    /**
     * Mutateur de l'attribut motif
     *
     * @param motif couleur à considérer comme un motif
     */
    public void setMotif(Color motif) {
        this.motif = motif;
    }

    /**
     * Mutateur de balleBlanche (balle blanche du jeu de billard)
     *
     * @param balleBlanche Objet BalleStructure à considérer comme une balle
     * blanche
     */
    public void setBalleBlanche(BalleStructure balleBlanche) {
        this.balleBlanche = balleBlanche;
    }

    /**
     * Mutateur de la balle1
     *
     * @param balle BalleStructure qui remplacera la balle1
     */
    public void setBalle1(BalleStructure balle) {
        this.balle1 = balle;
    }

    /**
     * Mutateur de la balle2
     *
     * @param balle BalleStructure qui remplacera la balle2
     */
    public void setBalle2(BalleStructure balle) {
        this.balle2 = balle;
    }

    /**
     * Mutateur de la balle3
     *
     * @param balle BalleStructure qui remplacera la balle3
     */
    public void setBalle3(BalleStructure balle) {
        this.balle3 = balle;
    }

    /**
     * Mutateur de la balle4
     *
     * @param balle BalleStructure qui remplacera la balle4
     */
    public void setBalle4(BalleStructure balle) {
        this.balle4 = balle;
    }

    /**
     * Constructeur de l'EnsembleDeBalles à placer sur une surface de jeu
     * précise
     *
     * @param surfaceDeJeu Tapis de jeu
     */
    public EnsembleDeBalles(Table surfaceDeJeu) {

        balleBlanche = new BalleStructure(new Balle(0, 15, Color.WHITE, surfaceDeJeu.getBoundsInLocal().getWidth() / 3, surfaceDeJeu.getBoundsInLocal().getHeight() / 2), 0.162);

        balleBlanche.setLayoutX(350.6666666666667);
        balleBlanche.setLayoutY(276.0);

        //Balles sans motifs
        balle1 = new BalleStructure(new Balle(1, 15, Color.RED, 701.3333333333334, 276.0), 0.162);
        balle2 = new BalleStructure(new Balle(2, 15, Color.BLUE, 723.8333333333334, 253.5), 0.162);
        balle3 = new BalleStructure(new Balle(3, 15, Color.YELLOW, 723.8333333333334, 298.5), 0.162);
        balle4 = new BalleStructure(new Balle(4, 15, Color.CYAN, 746.3333333333334, 276.0), 0.162);

        //Ajout des balles au tableau tabBalles
        tabBalles[0] = balleBlanche;
        tabBalles[1] = balle1;
        tabBalles[2] = balle2;
        tabBalles[3] = balle3;
        tabBalles[4] = balle4;

        surfaceDeJeu.getChildren().addAll(Arrays.asList(tabBalles));
    }

    /**
     * Méthode qui permet de positionner les balles pour le premier coup
     *
     * @param surfaceDeJeu Objet Table qui représente la table de billard
     */
    public void initialiserBalles(Table surfaceDeJeu) {

        balle1.setLayoutY(276.0);
        balle1.setLayoutX(701.3333333333334);

        balle3.setLayoutY(298.5);
        balle3.setLayoutX(723.8333333333334);

        balle2.setLayoutY(253.5);
        balle2.setLayoutX(723.8333333333334);

        balle4.setLayoutY(276.0);
        balle4.setLayoutX(746.3333333333334);

        balleBlanche.setLayoutY(276.0);
        balleBlanche.setLayoutX(350.6666666666667);

    }

    /**
     * Méthode qui retourne une valeur booléenne signalant si toutes les balles
     * sont immobiles
     *
     * @return Valeur booléenne qui indique si toutes les balles sont immobiles
     */
    public boolean allImmobiles() {
        int nbImmobiles = 0;
        for (BalleStructure tabBalle : tabBalles) {
            if (tabBalle.getVarX() == 0 && tabBalle.getVarY() == 0) {
                nbImmobiles++;
            }
        }
        return nbImmobiles == tabBalles.length;
    }

    /**
     * Méthode qui gère les collisions avec la Table
     *
     * @param table Objet Table représentant la table de billard
     */
    public void gestionCollisionsTable(Table table) {
        //Si les balles entrent en collision avec la table
        observeTable(table);
        //gestionTrousDeTable(table);

    }

    /**
     * Méthode qui gère les collisions entre les balles
     *
     */
    public void gestionCollisionsBalle(Table table) {
        observeBalles(table);

    }

    /**
     * Méthode qui observe si une balle touche la table
     *
     * @param table
     */
    public void observeTable(Table table) {
        for (BalleStructure tabBalle : tabBalles) {
            if (tabBalle.collisionsTable(table)[0] || tabBalle.collisionsTable(table)[1]) {
                tabBalle.setVarX(tabBalle.getVarX() * -1);
            }
            if (tabBalle.collisionsTable(table)[2] || tabBalle.collisionsTable(table)[3]) {
                tabBalle.setVarY(tabBalle.getVarY() * -1);
            }
        }
    }

    /**
     * À PUBLIER LORS DE LA VERSION 4 Méthode qui permet de traiter les
     * collisions avec la nouvelle table
     */
    public void collisionsTableGraphique(ArrayList<Path> list) {
        for (BalleStructure tabBalle : tabBalles) {
            if (tabBalle.getBoundsInParent().intersects(list.get(0).getBoundsInParent())) { //Collision avec le côté gauche (utilisateur)
                System.out.println("a");
                tabBalle.setVarX(tabBalle.getVarX() * -1);
                return;
            } else if (tabBalle.getBoundsInParent().intersects(list.get(2).getBoundsInParent())) {//Collision avec le côté droit (utilisateur)
                System.out.println("b");
                tabBalle.setVarY(tabBalle.getVarY() * -1);
                return;
            } else if (tabBalle.getBoundsInParent().intersects(list.get(1).getBoundsInParent())) {
                System.out.println("c");
                tabBalle.setVarX(tabBalle.getVarX() * -1);
                return;
            } else if (tabBalle.getBoundsInParent().intersects(list.get(3).getBoundsInParent())) {
                tabBalle.setVarY(tabBalle.getVarY() * -1);
                System.out.println("d");
                return;
            } else if (tabBalle.getBoundsInParent().intersects(list.get(4).getBoundsInParent())) {
                tabBalle.setVarY(tabBalle.getVarY() * -1);
                System.out.println("e");
                return;
            } else if (tabBalle.getBoundsInParent().intersects(list.get(5).getBoundsInParent())) {
                tabBalle.setVarY(tabBalle.getVarY() * -1);
                System.out.println("f");
                return;
            }
        }
    }

    /**
     * Méthode qui observe si deux balles se touchent CONCEPT PHYSIQUE
     * Collisions élastiques: Momentum Formule: Unités: P: masse de la balle *
     * vitesse: kg*m/s Pix+Piy = PfxBalle1+PfyBalle1 + PfxBalle2 + PfyBalle2
     * m1u1+m2u2 = m1v1+m2v2
     */
    public void observeBalles(Table table) {
        Thread tCB = new Thread() {
            public void run() {
                for (int i = 0; i < tabBalles.length; i++) {
                    for (int j = 0; j < tabBalles.length; j++) {
                        if (i != j) {
                            if (tabBalles[i].getBoundsInParent().intersects(tabBalles[j].getBoundsInParent())) {
                                //On conserve en mémoire la vitesse de la tabBalles[i]
                                double vitesseCollision = tabBalles[i].obtenirVitesseActuelle();
                                //On conserve en mémoire l'angle auquel relancer la balle lancée
                                double angleF = angleDeviation(tabBalles[i], tabBalles[j], table);
                                //On conserve en mémoire le momentum Piy
                                double piY = (tabBalles[i].getMasse() * tabBalles[i].getVarY()) + (tabBalles[j].getMasse() * tabBalles[j].getVarY());
                                //On conserve en mémoire le momentum Pix
                                double piX = (tabBalles[i].getMasse() * tabBalles[i].getVarX()) + (tabBalles[j].getMasse() * tabBalles[j].getVarX());
                                //On conserve en mémoire le momentum pfYA
                                double pfYA = tabBalles[i].getMasse() * (vitesseCollision * (Math.sin(angleF)));
                                //On conserve en mémoire le momentum pfYA
                                double pfXA = tabBalles[i].getMasse() * (vitesseCollision * (Math.cos(angleF)));
                                //Lancement des balles
                                //Nouvelles vars de tabBalles[i]
                                double newVarX = pfXA / tabBalles[i].getMasse();
                                double newVarY = pfYA / tabBalles[i].getMasse();
                                tabBalles[i].setVarX(newVarX);
                                tabBalles[i].setVarY(newVarY);
                                iniBalleFrappee(tabBalles[j], piX, piY, pfXA, pfYA);
                                return;
                            }
                        }
                    }
                }
            }
        };
        tCB.start();

    }

    /**
     * Méthode qui stoppe les balles inactives
     *
     */
    public void ballesInactives() {
        //Vérifie si la balle est arrêtée
        for (BalleStructure tabBalle : tabBalles) {
            if (Math.sqrt(Math.pow(tabBalle.getVarX(), 2) + Math.pow(tabBalle.getVarY(), 2)) < 0.009) {
                tabBalle.setVarX(0);
                tabBalle.setVarY(0);
                tabBalle.setEnMouvement(false);
            }
        }
    }

    /**
     * Méthode qui actualise les balles
     *
     */
    public void actualiserBalles() {
        //Préparation au lancement
        for (BalleStructure tabBalle : tabBalles) {
            Platform.runLater(() -> {
                tabBalle.updatePositionBalle(tabBalle.getVarX(), tabBalle.getVarY());
            });
            //Variation de la vitesse dans le temps
            tabBalle.setVarX(tabBalle.decelerationBalle(tabBalle.getVarX()));
            tabBalle.setVarY(tabBalle.decelerationBalle(tabBalle.getVarY()));

        }

        //Vérification des balles à arrêter
        ballesInactives();

    }

    /**
     * Méthode qui gère le moment où une balle croise un trou de la table (par
     * Victor Rondeau)
     *
     * @param table Objet de type Table qui représenta la table de billard
     */
    public void gestionTrousDeTable(Table table) {
        for (int i = 0; i < tabBalles.length; i++) {
            if (tabBalles[i].getLayoutX() >= table.getTrouSuperieurGauche().getLayoutX() - table.getTrouSuperieurGauche().getRadius() & tabBalles[i].getLayoutX() <= table.getTrouSuperieurGauche().getLayoutX() + table.getTrouSuperieurGauche().getRadius() & tabBalles[i].getLayoutY() >= table.getTrouSuperieurGauche().getLayoutY() - table.getTrouSuperieurGauche().getRadius() & tabBalles[i].getLayoutY() <= table.getTrouSuperieurGauche().getLayoutY() + table.getTrouSuperieurGauche().getRadius()) {
                teleportBalle(tabBalles[i]);
                //Coordonnées qui font déplacer la balle pour le trou supérieur du milieu
            } else if (tabBalles[i].getLayoutX() >= table.getTrouSuperieurMilieu().getLayoutX() - table.getTrouSuperieurMilieu().getRadius() & tabBalles[i].getLayoutX() <= table.getTrouSuperieurMilieu().getLayoutX() + table.getTrouSuperieurMilieu().getRadius() & tabBalles[i].getLayoutY() >= table.getTrouSuperieurMilieu().getLayoutY() - table.getTrouSuperieurMilieu().getRadius() & tabBalles[i].getLayoutY() <= table.getTrouSuperieurMilieu().getLayoutY() + table.getTrouSuperieurGauche().getRadius()) {
                teleportBalle(tabBalles[i]);
                //Coordonnées qui font déplacer la balle pour le trou supérieur droit
            } else if (tabBalles[i].getLayoutX() >= table.getTrouSuperieurDroite().getLayoutX() - table.getTrouSuperieurDroite().getRadius() & tabBalles[i].getLayoutX() <= table.getTrouSuperieurDroite().getLayoutX() + table.getTrouSuperieurDroite().getRadius() & tabBalles[i].getLayoutY() >= table.getTrouSuperieurDroite().getLayoutY() - table.getTrouSuperieurDroite().getRadius() & tabBalles[i].getLayoutY() <= table.getTrouSuperieurDroite().getLayoutY() + table.getTrouSuperieurDroite().getRadius()) {
                teleportBalle(tabBalles[i]);
                //Coordonnées qui font déplacer la balle pour le trou inférieur gauche
            } else if (tabBalles[i].getLayoutX() >= table.getTrouInferieurGauche().getLayoutX() - table.getTrouInferieurGauche().getRadius() & tabBalles[i].getLayoutX() <= table.getTrouInferieurGauche().getLayoutX() + table.getTrouInferieurGauche().getRadius() & tabBalles[i].getLayoutY() >= table.getTrouInferieurGauche().getLayoutY() - table.getTrouInferieurGauche().getRadius() & tabBalles[i].getLayoutY() <= table.getTrouInferieurGauche().getLayoutY() + table.getTrouInferieurGauche().getRadius()) {
                teleportBalle(tabBalles[i]);
                //Coordonnées qui font déplacer la balle pour le trou inférieur du milieu
            } else if (tabBalles[i].getLayoutX() >= table.getTrouInferieurMilieu().getLayoutX() - table.getTrouInferieurMilieu().getRadius() & tabBalles[i].getLayoutX() <= table.getTrouInferieurMilieu().getLayoutX() + table.getTrouInferieurMilieu().getRadius() & tabBalles[i].getLayoutY() >= table.getTrouInferieurMilieu().getLayoutY() - table.getTrouInferieurMilieu().getRadius() & tabBalles[i].getLayoutY() <= table.getTrouInferieurMilieu().getLayoutY() + table.getTrouInferieurMilieu().getRadius()) {
                teleportBalle(tabBalles[i]);
                //Coordonnées qui font déplacer la balle pour le trou inférieur droite
            } else if (tabBalles[i].getLayoutX() >= table.getTrouInferieurDroite().getLayoutX() - table.getTrouInferieurDroite().getRadius() & tabBalles[i].getLayoutX() <= table.getTrouInferieurDroite().getLayoutX() + table.getTrouInferieurDroite().getRadius() & tabBalles[i].getLayoutY() >= table.getTrouInferieurDroite().getLayoutY() - table.getTrouInferieurDroite().getRadius() & tabBalles[i].getLayoutY() <= table.getTrouInferieurDroite().getLayoutY() + table.getTrouInferieurDroite().getRadius()) {
                teleportBalle(tabBalles[i]);
            }
        }
    }

    public void teleportBalle(BalleStructure uneBalle) {//Version 3
        if (uneBalle.getBalle().getCouleur() == Color.WHITE) {
            uneBalle.stopBalle();
            uneBalle.setLayoutX(20);
            uneBalle.setLayoutY(550);
            uneBalle.getBalle().setBalleEntree(true);
        } else {
            uneBalle.stopBalle();
            uneBalle.setLayoutX(25 + getNombreBallesEntrees() * 30);
            uneBalle.setLayoutY(605);
            setNombreBallesEntrees(getNombreBallesEntrees() + 1);
        }
    }

    /**
     * Méthode qui retourne l'angle (en radians) auquel une balle lancée est
     * déviée
     *
     */
    public double angleDeviation(BalleStructure balleA, BalleStructure balleB, Table table) {
        //Il faut d'abord trouver le commencement en X et en Y de la ligne
        double startX = balleA.getBoundsInParent().getMaxX() - balleA.getBalle().getRadius();
        double startY = balleA.getBoundsInParent().getMaxY() - balleA.getBalle().getRadius();
        //Coordonnées en X et en Y de la fin de la ligne
        double endX = balleB.getBoundsInParent().getMaxX() - balleB.getBalle().getRadius();
        double endY = balleB.getBoundsInParent().getMaxY() - balleB.getBalle().getRadius();
        //Calcul de l'angle de la pende de la Line: utilisation de deltaY/deltaX
        double deltaX = startX - endX;
        double deltaY = endY - startY;
        return Math.atan(deltaY / deltaX);
    }

    /**
     * Méthode qui calcule la vitesse de la balle frappée
     */
    public void iniBalleFrappee(BalleStructure balle, double piX, double piY, double pfXA, double pfYA) {
        //Calcul de la composante en Y de la vitesse recherchée
        double vy = (piY - pfYA) / balle.getMasse();
        //Calcul de la composante en X de la vitesse recherchée
        double vx = (piX - pfXA) / balle.getMasse();
        balle.setVarX(vx);
        balle.setVarY(vy);
        if (Math.atan(vy / vx) > 0) {
            balle.setAngle(Math.atan(vy / vx));
        } else {
            balle.setAngle(Math.PI + Math.atan(vy / vx));
        }
    }

    /**
     * Méthode qui permet de détecter le collisions entre les balles et entre
     * une balle et les bords de la table
     *
     * @param angle Angle auquel la Balle est lancée
     * @param vitesse Vitesse à laquelle la Balle est lancée
     * @param table Table qui représente la table de billard
     */
    public void effectuerTour(double angle, double vitesse, Table table, ArrayList<Path> pathList) {
        //Collisions entre les murs de la table et entre les balles
        collisionsTableGraphique(pathList);
        //gestionCollisionsTable(table);
        gestionCollisionsBalle(table);

    }

    /**
     * @return the nombreBallesEntrees
     */
    public int getNombreBallesEntrees() {
        return nombreBallesEntrees;
    }

    /**
     * @param nombreBallesEntrees the nombreBallesEntrees to set
     */
    public void setNombreBallesEntrees(int nombreBallesEntrees) {
        this.nombreBallesEntrees = nombreBallesEntrees;
    }

}
