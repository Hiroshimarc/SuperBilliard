/*
 * Ensemble des balles 
 */
package Modèle;

import java.util.ArrayList;
import javafx.scene.paint.Color;
import Modèle.Table;
import java.awt.Window;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.scene.shape.Line;
import javax.swing.JOptionPane;
import vue.MenuJouer;

/**
 * 2017-02-27
 * @author Vittorio Passuello-Dussault
 * @version 1.0
 * @see Balle
 */
public class EnsembleDeBalles extends BalleBlanche{
    
    //Attributs
    //Désuet: public ArrayList<Balle> balles = new ArrayList<>();
    
    //En dév: Implémentation de l'EnsembleDeBalles en tableau
    public Balle[] tabBalles = new Balle[2];
    
    Balle balle1,balle2,balle3,balle4,balle5,balle6,balle7,balle9,balle10,balle11,balle12,balle13,balle14,balle15, balleFictive;
    public BalleBlanche balleBlanche;
    Color motif = Color.WHITE;
    int numeroBalleTouchee;
    
    /**Constructeur de l'EnsembleDeBalles à placer sur une surface de jeu précise
     * 
     * @param surfaceDeJeu Tapis de jeu
     */
    public EnsembleDeBalles(Table surfaceDeJeu){
            
            balleBlanche = new BalleBlanche(15,surfaceDeJeu);
        
            balle9 = new Balle(9,15,Color.RED,surfaceDeJeu.getLayoutBounds().getMinX()+50,60);
            //balle9.setStroke(motif);
            
            balle10 = new Balle(10,15,Color.BLUE,surfaceDeJeu.getLayoutBounds().getMinX()+50,90);
            //balle10.setStroke(motif);

            balle11 = new Balle(11,15,Color.YELLOW,surfaceDeJeu.getLayoutBounds().getMinX()+50,120);
            //balle11.setStroke(motif);
            
            balle12 = new Balle(12,15,Color.CYAN,surfaceDeJeu.getLayoutBounds().getMinX()+50,150);
            //balle12.setStroke(motif);
            
            balle13 = new Balle(13,15,Color.PURPLE,surfaceDeJeu.getLayoutBounds().getMinX()+50,180);
            //balle13.setStroke(motif);
            
            balle14 = new Balle(14,15,Color.CHARTREUSE,surfaceDeJeu.getLayoutBounds().getMinX()+50,210);
            //balle14.setStroke(motif);
            
            balle15 = new Balle(15,15,Color.DARKGOLDENROD,surfaceDeJeu.getLayoutBounds().getMinX()+50,240);
            //balle15.setStroke(motif);
            
            //Balles sans motifs
            balle1 = new Balle(1,15,Color.RED,surfaceDeJeu.getLayoutBounds().getMaxX()-50,60);
            //balle1.setStroke(Color.RED);
            
            balle2 = new Balle(2,15,Color.BLUE,surfaceDeJeu.getLayoutBounds().getMaxX()-50,90);
            //balle2.setStroke(Color.BLUE);
            
            balle3 = new Balle(3,15,Color.YELLOW,surfaceDeJeu.getLayoutBounds().getMaxX()-50,120);
            //balle3.setStroke(Color.YELLOW);
            
            balle4 = new Balle(4,15,Color.CYAN,surfaceDeJeu.getLayoutBounds().getMaxX()-50,150);
            //balle4.setStroke(Color.CYAN);
            
            balle5 = new Balle(5,15,Color.PURPLE,surfaceDeJeu.getLayoutBounds().getMaxX()-50,180);
            //balle5.setStroke(Color.PURPLE);
            
            balle6 = new Balle(6,15,Color.CHARTREUSE,surfaceDeJeu.getLayoutBounds().getMaxX()-50,210);
            //balle6.setStroke(Color.CHARTREUSE);
            
            balle7 = new Balle(7,15,Color.DARKGOLDENROD,surfaceDeJeu.getLayoutBounds().getMaxX()-50,240);
            //balle7.setStroke(Color.DARKGOLDENROD);
            
            balleFictive = new Balle(99,15,Color.BLACK,surfaceDeJeu.getWidth()/3+240,surfaceDeJeu.getHeight()/2);
            
            //Ajout des balles au tableau tabBalles
            tabBalles[0] = balleBlanche;
            tabBalles[1] = balleFictive;
            
            //balles.add(balleBlanche);
            //balles.add(balleFictive);
            /*balles.add(balle1);
            balles.add(balle2);
            balles.add(balle3);
            balles.add(balle4);
            balles.add(balle5);
            balles.add(balle6);
            balles.add(balle7);
            balles.add(balle9);
            balles.add(balle10);
            balles.add(balle11);
            balles.add(balle12);
            balles.add(balle13);
            balles.add(balle14);
            balles.add(balle15);*/
            
        /*for(int count=0;count<balles.size();count++){
            surfaceDeJeu.getChildren().add(balles.get(count));
        }*/
        
        for(int i=0;i<tabBalles.length;i++){
            surfaceDeJeu.getChildren().add(tabBalles[i]);
        }
    }
    
    /**Méthode qui permet de positionner les balles pour le premier coup
     * 
     */
    public void initialiserBalles(Table surfaceDeJeu){
        
        balle9.setPositionInitialeY(surfaceDeJeu.getHeight()/2);
        balle9.setPositionInitialeX(2*(surfaceDeJeu.getWidth()/3));
        
        balle7.setPositionInitialeY((surfaceDeJeu.getHeight()/2)-balle9.getRayon());
        balle7.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+2*(balle9.getRayon()));
        
        balle12.setPositionInitialeY((surfaceDeJeu.getHeight()/2)+balle9.getRayon());
        balle12.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+2*(balle9.getRayon()));
        
        balle15.setPositionInitialeY((surfaceDeJeu.getHeight()/2)-(2*(balle9.getRayon())));
        balle15.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+4*(balle9.getRayon()));
        
        balle1.setPositionInitialeY((surfaceDeJeu.getHeight()/2)+(2*(balle9.getRayon())));
        balle1.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+4*(balle9.getRayon()));
        
        balle6.setPositionInitialeY((surfaceDeJeu.getHeight()/2)-(3*(balle9.getRayon())));
        balle6.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+6*(balle9.getRayon()));
        
        balle10.setPositionInitialeY((surfaceDeJeu.getHeight()/2)-balle9.getRayon());
        balle10.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+6*(balle9.getRayon()));
        
        balle3.setPositionInitialeY((surfaceDeJeu.getHeight()/2)+balle9.getRayon());
        balle3.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+6*(balle9.getRayon()));
        
        balle14.setPositionInitialeY((surfaceDeJeu.getHeight()/2)+(3*(balle9.getRayon())));
        balle14.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+6*(balle9.getRayon()));
        
        balle11.setPositionInitialeY((surfaceDeJeu.getHeight()/2)-(4*(balle9.getRayon())));
        balle11.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+8*(balle9.getRayon()));
        
        balle2.setPositionInitialeY((surfaceDeJeu.getHeight()/2)-(2*(balle9.getRayon())));
        balle2.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+8*(balle9.getRayon()));
        
        balle13.setPositionInitialeY((surfaceDeJeu.getHeight()/2));
        balle13.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+8*(balle9.getRayon()));
        
        balle4.setPositionInitialeY((surfaceDeJeu.getHeight()/2)+(2*(balle9.getRayon())));
        balle4.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+8*(balle9.getRayon()));
        
        balle5.setPositionInitialeY((surfaceDeJeu.getHeight()/2)+(4*(balle9.getRayon())));
        balle5.setPositionInitialeX((2*(surfaceDeJeu.getWidth()/3))+8*(balle9.getRayon()));
    }
    
    /**Méthode qui calcule et retourne l'angle de la droite qui sépare le milieu des deux balles
     * 
     */
    public double angleDroiteTangente(Balle balle1, Balle balle2){
        //Centres des balles en x
        double cb1x = balle1.getBoundsInParent().getMaxX()-balle1.getRayon();
        double cb2x = balle2.getBoundsInParent().getMaxX()-balle2.getRayon();
        //Centres des balles en Y
        double cb1y = balle1.getBoundsInParent().getMaxY()-balle1.getRayon();
        double cb2y = balle2.getBoundsInParent().getMaxY()-balle2.getRayon();
        //deltas des coordonnees
        double deltaX = (cb2x-cb1x);
        double deltaY = (cb2y-cb2y);
        //angle de la droite
        double angleDroite = Math.toRadians(Math.atan(deltaY/deltaX));
        return angleDroite;
    }
    
    /**Méthode qui gère les collisions entre les balles EN DÉVELOPPEMENT
     * 
     */
    public void collisionsBalles(){
        
        Platform.runLater(new Runnable() {
            @Override public void run() {
                //Si les balles entrent en collision
                if(tabBalles[0].getBoundsInParent().intersects(tabBalles[1].getBoundsInParent())){
                    double vitesseCollision=0;
                    //Si une seule des Balles en en mouvement:
                    //Si la balle blanche bouge et que la balle fictive est immobile
                    if(tabBalles[0].obtenirVitesseActuelle()!=0 && tabBalles[1].obtenirVitesseActuelle()==0){
                        lancerBallePercutee(tabBalles[0], tabBalles[1]);
                    }else if(tabBalles[0].obtenirVitesseActuelle()==0 && tabBalles[1].obtenirVitesseActuelle()!=0){
                        lancerBallePercutee(tabBalles[1], tabBalles[0]);
                    }
                }
            } 
        });
    }
    
    /**Méthode qui retourne une valeur booléenne signalant si toutes les balles sont immobiles
     * 
     */
    public boolean allImmobiles(){
        int nbImmobiles=0;
        for(int i=0;i<tabBalles.length;i++){
            if(tabBalles[i].getVarX()==0 && tabBalles[i].getVarY()==0){
                nbImmobiles++;
            }
        }
        if(nbImmobiles==tabBalles.length){
            return true;
        }else{
            return false;
        }
    }
    
    /**Méthode qui gère les collisions des balles avec les murs
     * 
     */
    public void gestionCollisionsTable(Table table){ 
        Platform.runLater(new Runnable() {
            @Override public void run() {
                if (tabBalles[1].collisionsTable(table)[0] || tabBalles[1].collisionsTable(table)[1]) {
                    tabBalles[1].setVarX(tabBalles[1].getVarX()*-1);
                    tabBalles[1].setAngle(tabBalles[1].getAngle()+Math.toRadians(180));
                }

                if (tabBalles[1].collisionsTable(table)[2] || tabBalles[1].collisionsTable(table)[3]) {
                    tabBalles[1].setVarY(tabBalles[1].getVarY()*-1);
                }

                if (tabBalles[0].collisionsTable(table)[0] || tabBalles[0].collisionsTable(table)[1]) {
                        tabBalles[0].setVarX(tabBalles[0].getVarX()*-1);
                        tabBalles[0].setAngle(tabBalles[0].getAngle()+Math.toRadians(180));
                    }

                if(tabBalles[0].collisionsTable(table)[2] || tabBalles[0].collisionsTable(table)[3]) {
                    tabBalles[0].setVarY(tabBalles[0].getVarY()*-1);
                }                
            }
        });
    }
    
    /**Méthode qui stoppe les balles inactives
     * 
     */
    public void ballesInactives(){
        //Vérifie si la balle est arrêtée
        if(Math.sqrt(Math.pow(tabBalles[0].getVarX(), 2)+Math.pow(tabBalles[0].getVarY(), 2)) < 0.025){
            tabBalles[0].setVarX(0);
            tabBalles[0].setVarY(0);
            tabBalles[0].setEnMouvement(false);
        }
        if(Math.sqrt(Math.pow(tabBalles[1].getVarX(), 2)+Math.pow(tabBalles[1].getVarY(), 2)) < 0.025){
            tabBalles[1].setVarX(0);
            tabBalles[1].setVarY(0);
            tabBalles[1].setEnMouvement(false);
        }

    }
    
    /**Méthode qui actualise les balles
     * 
     */
    public void actualiserBalles(){
        Platform.runLater(new Runnable() {
            @Override public void run() {
                //Préparation au lancement
                tabBalles[0].updatePositionBalle(tabBalles[0].getVarX(), tabBalles[0].getVarY());
                tabBalles[1].updatePositionBalle(tabBalles[1].getVarX(), tabBalles[1].getVarY());
            }
        });
            //Variation de la vitesse dans le temps
            tabBalles[0].setVarX(tabBalles[0].decelerationBalle(tabBalles[0].getVarX()));
            tabBalles[0].setVarY(tabBalles[0].decelerationBalle(tabBalles[0].getVarY()));
            tabBalles[1].setVarX(tabBalles[1].decelerationBalle(tabBalles[1].getVarX()));
            tabBalles[1].setVarY(tabBalles[1].decelerationBalle(tabBalles[1].getVarY()));
            

        
    }
    
    /**Méthode qui permet la préparation du lancement de la balle percutée
     * 
     */
    public void lancerBallePercutee(Balle balleLancee, Balle balleFrappee){
        double vitesseCollision;
        double angleIncident;
        //En dév: Si l'angle de collision est quelconque
            //Temp: On immobilise la balleLancee, mais avant on sauvegarde sa vitesse d'incidence
            vitesseCollision = balleLancee.obtenirVitesseActuelle();
            balleLancee.stopBalle();
            
            //Il faut déterminer l'angle auquel il fault lancer balleFrappee
            angleIncident = balleLancee.getAngle();
            
            //utilisation de la formule de physique mécanique: v0ini = v0finale + v1initiale donc la balle frappee reçoit la vitesse de la balle lancee
            balleFrappee.prepareToLaunch(angleIncident, vitesseCollision);
    }
    
    /**Méthode qui retourne l'angle de collision
     * 
     */
    public double angleDeCollision(Balle balleLancee, Balle balleFrappee){
        //Il faut d'abord trouver le commencement en X et en Y de la ligne
        double startX = balleLancee.getBoundsInParent().getMaxX() - balleLancee.getRadius();
        double startY = balleLancee.getBoundsInParent().getMaxY() - balleLancee.getRadius();
        //Coordonnées en X et en Y de la fin de la ligne
        double endX = balleFrappee.getBoundsInParent().getMaxX() - balleFrappee.getRadius();
        double endY = balleFrappee.getBoundsInParent().getMaxY() - balleFrappee.getRadius();
        //Il faut définir une Line qui traversera le centre des deux balles
        Line ligneGuide = new Line(startX,startY,endX,endY);
        
        //Calcul de l'angle de la pende de la Line: utilisation de deltaY/deltaX
        double deltaX = endX-startX;
        double deltaY = endY-startY;
        return Math.atan(deltaY/deltaX);
        
    }
    
    
    
    /**Méthode qui permet de détecter le collisions entre les balles et entre une balle et les bords de la table
     * 
     */
    public void effectuerTour(double angle, double vitesse, Table table){
        //Collisions entre les murs de la table et entre les balles
        Thread tTour = new Thread(){
            public void run(){
                tabBalles[0].setVitesseDeLancement(vitesse);
                tabBalles[0].prepareToLaunch(angle, vitesse);
                //Définition du Thread
                Thread.currentThread().setName("Tour");
                Thread.currentThread().setPriority(Thread.NORM_PRIORITY);
                while(!allImmobiles()){
                    try {
                        //Conditions de collision avec la table
                        gestionCollisionsTable(table);

                        //Conditions de collision avec une autre balle
                        collisionsBalles();

                        //Actualisation des balles
                        actualiserBalles(); 

                        //Vérification des balles à arrêter
                        ballesInactives();

                        Thread.currentThread().sleep(1);
                    } catch (InterruptedException ex) {
                        break;
                    }
                };
                }

            };
        tTour.setDaemon(true);
        tTour.start();

    }
    
    
}
