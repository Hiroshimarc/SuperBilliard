package modele;

import javafx.scene.paint.Color;

/** Classe représentant la balle blanche dans un ensemble de balles au billard
 * 2017-04-09
 * @author Vittorio Passuello-Dussault
 * @see Balle
 * @version 0.2
 */

public class BalleBlanche extends Balle{
    /**Constructeur avec paramètres de l'objet BalleBlanche
     * 
     * @param rayon Rayon de la BalleBlanche
     * @param surfaceDeJeu Objet Table qui représente la table de billard
     */
    public BalleBlanche(double rayon,Table surfaceDeJeu){
       this.setPositionInitialeX(surfaceDeJeu.getBoundsInLocal().getWidth()/3);
       this.setPositionInitialeY(surfaceDeJeu.getBoundsInLocal().getHeight()/2);
       this.setCouleur(Color.WHITE);
       this.setEnMouvement(false);
       this.setRayon(rayon);
    }
    
    /**Constructeur par défaut de l'objet BalleBlanche
     * 
     */
    public BalleBlanche(){
        
    }
}
