/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import controleur.Launcher;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import modele.Balle;
import modele.EnsembleDeBalles;
import modele.Table;

/**
 * Classe qui représente le menu jouer du menu principal
 *
 * @author Édouard Raffis
 * @version 2.0 2017-04-09
 */
public class MenuJouer {

    Stage superBillard;
    Scene menuJouer;
    AnchorPane paneJouer;
    Button boutonMenu, boutonMusique;
    Table table;
    Label indicationVitesse;
    Label vitesseActuelle;
    Slider saisieVitesse;
    Label indicationAngle;
    public static Label attenteTour;
    public static TextField saisieAngle;
    public static TextField visualiserVitesse;
    public static Button appliquerVitesse, visualiserAngle;
    Rectangle graduationG;
    Rectangle graduationY;
    Rectangle graduationR;
    Rectangle boiteBoule;
    Line visualisation;
    boolean alreadyDrawnDirectionLine = false; // Si une ligne indicatrice est déj<a tracée
    double x, y, deltX, deltY;
    boolean balleBlancheDraggable = true;
    public static String background;

    /**
     * Constructeur de l'objet MenuJouer
     *
     * @param stage stage
     */
    public MenuJouer(Stage stage) {
        table = new Table(10, 10, 1000, 500, Color.GREEN, Color.BROWN, Color.rgb(128, 0, 0));
        this.superBillard = stage;
        paneJouer = new AnchorPane();

        boutonMenu = new Button("Retourner au menu principal");
        boutonMusique = new Button("", new ImageView(new Image("musicLogo.png", 15, 15, true, true)));

        AnchorPane.setRightAnchor(boutonMenu, Double.valueOf(10));
        AnchorPane.setBottomAnchor(boutonMenu, Double.valueOf(50));

        AnchorPane.setBottomAnchor(boutonMusique, Double.valueOf(0));
        AnchorPane.setRightAnchor(boutonMusique, Double.valueOf(0));

        boutonMusique.setStyle(
                " -fx-text-fill: white;"
                + "-fx-font-size: 15px;"
                + "-fx-pref-width: 15px;"
        );

        appliquerVitesse = new Button("GO!");
        appliquerVitesse.setMaxSize(50, 50);
        appliquerVitesse.setLayoutX(1120);
        appliquerVitesse.setLayoutY(300);
        appliquerVitesse.setDefaultButton(true);

        visualiserAngle = new Button("Visualiser");
        visualiserAngle.setMaxSize(100, 100);
        visualiserAngle.setLayoutX(1105);
        visualiserAngle.setLayoutY(270);

        indicationVitesse = new Label("Vitesse:");
        indicationVitesse.setMaxSize(150, 30);
        indicationVitesse.setLayoutX(1070);
        indicationVitesse.setLayoutY(80);

        attenteTour = new Label("Veuillez attendre la fin du tour");
        attenteTour.setMaxSize(200, 40);
        attenteTour.setLayoutX(1070);
        attenteTour.setLayoutY(320);

        vitesseActuelle = new Label("Vitesse actuelle");
        vitesseActuelle.setMaxSize(200, 40);
        vitesseActuelle.setLayoutX(1070);
        vitesseActuelle.setLayoutY(340);

        saisieVitesse = new Slider();
        saisieVitesse.setMaxSize(150, 30);
        saisieVitesse.setLayoutX(1070);
        saisieVitesse.setLayoutY(120);
        saisieVitesse.setMin(0);
        saisieVitesse.setMax(4);

        indicationAngle = new Label("Angle:");
        indicationAngle.setMaxSize(150, 30);
        indicationAngle.setLayoutX(1070);
        indicationAngle.setLayoutY(180);

        saisieAngle = new TextField("");
        saisieAngle.setMaxSize(150, 30);
        saisieAngle.setLayoutX(1070);
        saisieAngle.setLayoutY(210);

        visualiserVitesse = new TextField("");
        visualiserVitesse.setMaxSize(150, 30);
        visualiserVitesse.setLayoutX(1070);
        visualiserVitesse.setLayoutY(360);
        visualiserVitesse.setEditable(false);

        graduationG = new Rectangle(1070, 120, 50, 15);
        graduationG.setFill(Color.GREEN);
        graduationY = new Rectangle(1120, 120, 50, 15);
        graduationY.setFill(Color.YELLOW);
        graduationR = new Rectangle(1170, 120, 50, 15);
        graduationR.setFill(Color.RED);

        boiteBoule = new Rectangle(10, 590, 1000, 125);
        boiteBoule.setFill(Color.TRANSPARENT);
        boiteBoule.setStroke(Color.BLACK);

        EnsembleDeBalles players = new EnsembleDeBalles(table);
        players.initialiserBalles(table);

        paneJouer.getChildren().addAll(table, graduationG, graduationR, graduationY, boiteBoule, boutonMenu, appliquerVitesse,
                indicationAngle, indicationVitesse, saisieAngle, saisieVitesse,
                visualiserAngle, visualiserVitesse, vitesseActuelle, boutonMusique);

        new Thread(() -> {
            Thread.currentThread().setName("Thread qui permet de rendre la balle blanche déplaçable");

            while (balleBlancheDraggable == true) {
                if (players.tabBalles[0].getLayoutX() >= table.getTrouSuperieurGauche().getLayoutX() - table.getTrouSuperieurGauche().getRadius() & players.tabBalles[0].getLayoutX() <= table.getTrouSuperieurGauche().getLayoutX() + table.getTrouSuperieurGauche().getRadius() & players.tabBalles[0].getLayoutY() >= table.getTrouSuperieurGauche().getLayoutY() - table.getTrouSuperieurGauche().getRadius() & players.tabBalles[0].getLayoutY() <= table.getTrouSuperieurGauche().getLayoutY() + table.getTrouSuperieurGauche().getRadius()) {
                    if (players.tabBalles[0].getCouleur() == Color.WHITE) {
                        deplacerBalleBlanche(players.tabBalles[0]);

                        try {
                            Thread.sleep(1);
                        } catch (InterruptedException ex) {
                            JOptionPane.showMessageDialog(null, "Thread Intérrompu"); // À  remplacer avec classe d'erreur
                        }
                    }
                } else if (players.tabBalles[0].getLayoutX() >= table.getTrouSuperieurMilieu().getLayoutX() - table.getTrouSuperieurMilieu().getRadius() & players.tabBalles[0].getLayoutX() <= table.getTrouSuperieurMilieu().getLayoutX() + table.getTrouSuperieurMilieu().getRadius() & players.tabBalles[0].getLayoutY() >= table.getTrouSuperieurMilieu().getLayoutY() - table.getTrouSuperieurMilieu().getRadius() & players.tabBalles[0].getLayoutY() <= table.getTrouSuperieurMilieu().getLayoutY() + table.getTrouSuperieurGauche().getRadius()) {
                    if (players.tabBalles[0].getCouleur() == Color.WHITE) {
                        deplacerBalleBlanche(players.tabBalles[0]);

                        try {
                            Thread.sleep(1);
                        } catch (InterruptedException ex) {
                            JOptionPane.showMessageDialog(null, "Thread Intérrompu"); // À  remplacer avec classe d'erreur
                        }
                    }
                } else if (players.tabBalles[0].getLayoutX() >= table.getTrouSuperieurDroite().getLayoutX() - table.getTrouSuperieurDroite().getRadius() & players.tabBalles[0].getLayoutX() <= table.getTrouSuperieurDroite().getLayoutX() + table.getTrouSuperieurDroite().getRadius() & players.tabBalles[0].getLayoutY() >= table.getTrouSuperieurDroite().getLayoutY() - table.getTrouSuperieurDroite().getRadius() & players.tabBalles[0].getLayoutY() <= table.getTrouSuperieurDroite().getLayoutY() + table.getTrouSuperieurDroite().getRadius()) {
                    if (players.tabBalles[0].getCouleur() == Color.WHITE) {
                        deplacerBalleBlanche(players.tabBalles[0]);

                        try {
                            Thread.sleep(1);
                        } catch (InterruptedException ex) {
                            JOptionPane.showMessageDialog(null, "Thread Intérrompu"); // À  remplacer avec classe d'erreur
                        }
                    }
                } else if (players.tabBalles[0].getLayoutX() >= table.getTrouInferieurGauche().getLayoutX() - table.getTrouInferieurGauche().getRadius() & players.tabBalles[0].getLayoutX() <= table.getTrouInferieurGauche().getLayoutX() + table.getTrouInferieurGauche().getRadius() & players.tabBalles[0].getLayoutY() >= table.getTrouInferieurGauche().getLayoutY() - table.getTrouInferieurGauche().getRadius() & players.tabBalles[0].getLayoutY() <= table.getTrouInferieurGauche().getLayoutY() + table.getTrouInferieurGauche().getRadius()) {
                    if (players.tabBalles[0].getCouleur() == Color.WHITE) {
                        deplacerBalleBlanche(players.tabBalles[0]);

                        try {
                            Thread.sleep(1);
                        } catch (InterruptedException ex) {
                            JOptionPane.showMessageDialog(null, "Thread Intérrompu"); // À  remplacer avec classe d'erreur
                        }
                    }
                } else if (players.tabBalles[0].getLayoutX() >= table.getTrouInferieurMilieu().getLayoutX() - table.getTrouInferieurMilieu().getRadius() & players.tabBalles[0].getLayoutX() <= table.getTrouInferieurMilieu().getLayoutX() + table.getTrouInferieurMilieu().getRadius() & players.tabBalles[0].getLayoutY() >= table.getTrouInferieurMilieu().getLayoutY() - table.getTrouInferieurMilieu().getRadius() & players.tabBalles[0].getLayoutY() <= table.getTrouInferieurMilieu().getLayoutY() + table.getTrouInferieurMilieu().getRadius()) {
                    if (players.tabBalles[0].getCouleur() == Color.WHITE) {
                        deplacerBalleBlanche(players.tabBalles[0]);

                        try {
                            Thread.sleep(1);
                        } catch (InterruptedException ex) {
                            JOptionPane.showMessageDialog(null, "Thread Intérrompu"); // À  remplacer avec classe d'erreur
                        }
                    }
                } else if (players.tabBalles[0].getLayoutX() >= table.getTrouInferieurDroite().getLayoutX() - table.getTrouInferieurDroite().getRadius() & players.tabBalles[0].getLayoutX() <= table.getTrouInferieurDroite().getLayoutX() + table.getTrouInferieurDroite().getRadius() & players.tabBalles[0].getLayoutY() >= table.getTrouInferieurDroite().getLayoutY() - table.getTrouInferieurDroite().getRadius() & players.tabBalles[0].getLayoutY() <= table.getTrouInferieurDroite().getLayoutY() + table.getTrouInferieurDroite().getRadius()) {
                    if (players.tabBalles[0].getCouleur() == Color.WHITE) {
                        deplacerBalleBlanche(players.tabBalles[0]);

                        try {
                            Thread.sleep(1);
                        } catch (InterruptedException ex) {
                            JOptionPane.showMessageDialog(null, "Thread Intérrompu"); // À  remplacer avec classe d'erreur
                        }
                    }
                } else {
                    balleBlancheDraggable = false;
                }
            }
        }).start();

        menuJouer = new Scene(paneJouer, 1250, 725);

        boutonMenu.setOnAction((ActionEvent e) -> {
            MenuPrincipal menuPrincipal = new MenuPrincipal(superBillard);
            superBillard.setScene(menuPrincipal.getMenu());
            superBillard.centerOnScreen();

        });

        boutonMusique.setOnAction((ActionEvent e) -> {
            if (Launcher.mp.getStatus() == MediaPlayer.Status.PLAYING) {
                Launcher.mp.pause();
            }
            if (Launcher.mp.getStatus() == MediaPlayer.Status.PAUSED) {
                Launcher.mp.play();
            }
        });

        if (background == "Or") {
            Image or = new Image("Or.jpg", true);
            BackgroundImage orFond = new BackgroundImage(or, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
            paneJouer.setBackground(new Background(orFond));
        }
        if (background == "Tapis" | background == null) {
            Image feutre = new Image("Feutre.jpg", true);
            BackgroundImage feutreFond = new BackgroundImage(feutre, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
            paneJouer.setBackground(new Background(feutreFond));
        }

        if (background == "Glace") {
            Image glace = new Image("Glace.jpg", true);
            BackgroundImage glaceFond = new BackgroundImage(glace, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
            paneJouer.setBackground(new Background(glaceFond));
        }
        if (background == "Asphalte") {
            Image asphalte = new Image("Asphalte.jpg", true);
            BackgroundImage asphalteFond = new BackgroundImage(asphalte, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
            paneJouer.setBackground(new Background(asphalteFond));
        }

        boutonMenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {

                paneJouer.getChildren().clear();
                MenuPrincipal menuPrincipal = new MenuPrincipal(superBillard);
                superBillard.setScene(menuPrincipal.menuPrincipal);

            }
        }
        );

        visualiserAngle.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                String validAngleFormat = acceptedSeparator(saisieAngle.getText());
                double angle = Double.parseDouble(validAngleFormat);
                //Appel de méthode pour dessiner la ligne
                drawDirectionLine(players.tabBalles[0], angle, table);

            }
        });

        appliquerVitesse.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                table.getChildren().remove(visualisation);
                String validAngleFormat = acceptedSeparator(saisieAngle.getText());
                double angle = Double.parseDouble(validAngleFormat);
                //On demande la saisie de la vitesse qui sera considérée comme une vitesse en m/s
                double vitesse = saisieVitesse.getValue();
                players.effectuerTour(players.tabBalles[0].angleDeTir(angle), players.tabBalles[0].obtenirVitesseLancement(vitesse), table);
            }
        }
        );
    }

    /**
     * Méthode qui permet de retourner l'objet MenuJouer
     *
     * @return Objet MenuJouer
     */
    public Scene getMenu() {
        return menuJouer;
    }

    /**
     * Méthode qui permet de corriger une erreur courante lors de la saisie des
     * nombres à décimales (remplace les virgules et les momayyez par des points
     * pour assurer un bon fonctionnement du code)
     *
     * @author Vittorio Passuello-Dussault
     * @param angleInput
     * @return acceptedFormat (valeur booléenne qui indique si le format de
     * saisie est acceptable) Source des séparateurs mondiaux :
     * https://fr.wikipedia.org/wiki/S%C3%A9parateur_d%C3%A9cimal
     */
    public String acceptedSeparator(String angleInput) {
        final char possibleSeparator1 = ',', possibleSeparator2 = '٫', separator = '.';
        StringBuilder correct = new StringBuilder(angleInput);
        for (int count = 0; count < angleInput.length(); count++) {
            switch (angleInput.charAt(count)) {
                case possibleSeparator1:
                    correct.setCharAt(count, separator);
                case possibleSeparator2:
                    correct.setCharAt(count, separator);
            }
        }
        return correct.toString();
    }

    /**
     * Méthode qui permet de tracer la ligne de direction
     *
     * @param balle Balle qui est lancée
     * @param angle Angle auquel la Balle est lancée
     * @param table Objet Table qui représente la table de billard
     */
    public void drawDirectionLine(Balle balle, double angle, Table table) {
        if (alreadyDrawnDirectionLine) {
            table.getChildren().remove(visualisation);
            alreadyDrawnDirectionLine = false;
        }
        angle = angle - 270;
        angle = Math.toRadians(angle);

        //Distance entre la balle et le côté droit de la table
        double dbr = table.getBoundsInLocal().getMaxX() - 342;
        //Distance entre la balle et le côté gauche de la table
        double dbl = table.getBoundsInLocal().getMinX() + 303;
        //Distance entre la balle et le haut de la table
        //double dbu = 

        //Les points de débuts de la ligne sont les coordonnées de la balle
        double startX = balle.getLayoutX();
        double startY = balle.getLayoutY();

        //Calcul de la coordonnée finale en X avec hypothénuse arbitraire
        double endX = startX + dbl * (Math.sin(angle));
        double endY = startY + dbl * (Math.cos(angle));
        //Création de la Line
        visualisation = new Line(startX, startY, endX, endY);
        visualisation.setFill(Color.WHITE);
        visualisation.setStroke(Color.WHITE);
        table.getChildren().add(visualisation);
        alreadyDrawnDirectionLine = true;
    }

    /**
     * Méthode qui va permettre de pouvoir déplacer la balle blanche
     *
     * @param uneBalle Balle à déplacer
     */
    public void deplacerBalleBlanche(Balle uneBalle) {
        uneBalle.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                x = event.getSceneX();
                y = event.getSceneY();
                deltX = ((Balle) (event.getSource())).getTranslateX();
                deltY = ((Balle) (event.getSource())).getTranslateY();
            }
        });
        uneBalle.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                double orgX = event.getSceneX() - x;
                double orgY = event.getSceneY() - y;
                double newOrgX = deltX + orgX;
                double newOrgY = deltX + orgY;
                ((Balle) (event.getSource())).setTranslateX(newOrgX);
                ((Balle) (event.getSource())).setTranslateY(newOrgY);
            }
        });
        EventHandler<MouseEvent> unMouseEvent = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                balleBlancheDraggable = false;
            }
        };
        uneBalle.setOnMouseReleased(unMouseEvent);
    }
}
