/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import javax.swing.JOptionPane;
import vue.MenuJouer;

/**
 *
 * @author usager
 */
public class GestionPartie {

    Joueur joueur1, joueur2;
    String tour;

    public void debutterPartie() {
        joueur1 = new Joueur(JOptionPane.showInputDialog(null, "Entrer le nom du joueur 1"));
        joueur2 = new Joueur(JOptionPane.showInputDialog(null, "Entrer le nom du joueur 2"));
        this.tour = joueur1.getNom();
    }

    public void assignerTypeBalle(String unType, Joueur unJoueur) {
        if (unJoueur.getNom().equals(joueur1.getNom())) {
            joueur1.setTypeBalle(unType);
            //joueur2.setTypeBalle(autreType);
        } else {
            //joueur1.setTypeBalle(autreType);
            joueur2.setTypeBalle(unType);
        }
    }

    public void balleEmpochée(String unType, Joueur unJoueur) {
        if (unType == "balle noir") {
            if (unJoueur.getNbBalles() != 7) {
                JOptionPane.showMessageDialog(null, "Le joueur: " + unJoueur.getNom()
                        + " a perdu la partie, car il a empopché la balle noir.");
                //Reset Game
            } else {
                JOptionPane.showMessageDialog(null, "Le joueur: " + unJoueur.getNom()
                        + " a remporté la victoire!");
                //Reset Game
            }
        } else if (unType == "balle blanche") {
            JOptionPane.showMessageDialog(null, "Le joueur: " + unJoueur.getNom()
                    + " a empoché la balle blanche c'est donc le tour de l'autre joueur");
            
            changerDeTour(unJoueur);
        } else if (unJoueur.getTypeBalle().equals(unType)) {
            JOptionPane.showMessageDialog(null, "Le joueur: " + unJoueur.getNom()
                    + " a empoché le mauvais type de balle c'est donc le tour de l'autre joueur");
            changerDeTour(unJoueur);
        }
    }

    public void changerDeTour(Joueur unJoueur) {
        if (unJoueur.getNom().equals(joueur1.getNom())) {
            tour = joueur2.getNom();
        } else {
            tour = joueur1.getNom();
        }
    }
}
