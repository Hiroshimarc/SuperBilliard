package Modèle;

/**
 * 2017-02-28
 * @author Vittorio Passuello-Dussault
 * @see Balle
 * @version 1.0
 */
public class BalleHuit extends Balle{
    
}
