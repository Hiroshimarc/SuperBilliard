package modele;

/**
 *
 * @author Édouard Raffis
 */
public class Joueur {

    String nom;
    String typeBalle;
    int nbBalles;

    /**
     * Constructeur de l'objet joueur
     *
     * @param unNom
     */
    public Joueur(String unNom) {
        this.nom = unNom;
    }

    /**
     * Méthode qui retourne le type de balle d'un joueur
     *
     * @return
     */
    public String getTypeBalle() {
        return this.typeBalle;
    }

    /**
     * Méthode qui assigne un type de balle au joueur
     *
     * @param unType
     */
    public void setTypeBalle(String unType) {
        this.typeBalle = unType;
    }

    /**
     * Méthode qui retourne le nombre de balle qu'un joueur à rentré
     *
     * @return nbBalles
     */
    public int getNbBalles() {
        return this.nbBalles;
    }

    /**
     * Méthode qui assigne un nombre de balles empochées
     *
     * @param unNbBalles
     */
    public void setNbBalles(int unNbBalles) {
        this.nbBalles = unNbBalles;
    }

    /**
     * Méthode qui retourne le nom d'un joueur
     *
     * @return nom
     */
    public String getNom() {
        return this.nom;
    }

}
