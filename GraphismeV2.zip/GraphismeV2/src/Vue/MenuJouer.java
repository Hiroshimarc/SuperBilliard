/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author usager
 */
public class MenuJouer {
    
    Stage superBillard;
    Scene menuJouer;
    AnchorPane paneJouer;
    Button boutonMenu;
    
    Label indicationVitesse;
    Label vitesseActuelle;
    Slider saisieVitesse;
    Label indicationAngle;
    public static Label attenteTour;
    public static TextField saisieAngle;
    public static TextField visualiserVitesse;
    public static Button appliquerVitesse, visualiserAngle;
    Rectangle graduationG;
    Rectangle graduationY;
    Rectangle graduationR;
    Rectangle boiteBoule;
    Line visualisation;
    boolean alreadyDrawnDirectionLine = false; // Si une ligne indicatrice est déj<a tracée

    public MenuJouer(Stage stage) {
        this.superBillard = stage;
        paneJouer = new AnchorPane();
        
        boutonMenu = new Button("Retourner au menu principal");
        AnchorPane.setRightAnchor(boutonMenu, Double.valueOf(25));
        AnchorPane.setBottomAnchor(boutonMenu, Double.valueOf(10));
        
        appliquerVitesse = new Button("GO!");
        appliquerVitesse.setMaxSize(50, 50);
        appliquerVitesse.setLayoutX(1120);
        appliquerVitesse.setLayoutY(300);
        
        visualiserAngle = new Button("Visualiser");
        visualiserAngle.setMaxSize(100, 100);
        visualiserAngle.setLayoutX(1105);
        visualiserAngle.setLayoutY(270);
        
        indicationVitesse = new Label("Vitesse:");
        indicationVitesse.setMaxSize(150, 30);
        indicationVitesse.setLayoutX(1070);
        indicationVitesse.setLayoutY(80);
        
        attenteTour = new Label("Veuillez attendre la fin du tour");
        attenteTour.setMaxSize(200, 40);
        attenteTour.setLayoutX(1070);
        attenteTour.setLayoutY(320);
        
        vitesseActuelle = new Label("Vitesse actuelle");
        vitesseActuelle.setMaxSize(200, 40);
        vitesseActuelle.setLayoutX(1070);
        vitesseActuelle.setLayoutY(340);
        
        saisieVitesse = new Slider();
        saisieVitesse.setMaxSize(150, 30);
        saisieVitesse.setLayoutX(1070);
        saisieVitesse.setLayoutY(120);
        saisieVitesse.setMin(0);
        saisieVitesse.setMax(4);
        
        indicationAngle = new Label("Angle:");
        indicationAngle.setMaxSize(150, 30);
        indicationAngle.setLayoutX(1070);
        indicationAngle.setLayoutY(180);
        
        saisieAngle = new TextField("");
        saisieAngle.setMaxSize(150, 30);
        saisieAngle.setLayoutX(1070);
        saisieAngle.setLayoutY(210);
        
        visualiserVitesse = new TextField("");
        visualiserVitesse.setMaxSize(150, 30);
        visualiserVitesse.setLayoutX(1070);
        visualiserVitesse.setLayoutY(360);
        visualiserVitesse.setEditable(false);
        
        graduationG = new Rectangle(1070, 120, 50, 15);
        graduationG.setFill(Color.GREEN);
        graduationY = new Rectangle(1120, 120, 50, 15);
        graduationY.setFill(Color.YELLOW);
        graduationR = new Rectangle(1170, 120, 50, 15);
        graduationR.setFill(Color.RED);
        
        boiteBoule = new Rectangle(10, 590, 1000, 125);
        boiteBoule.setFill(Color.WHEAT);
       
        paneJouer .getChildren().addAll(graduationG, graduationR, graduationY, boiteBoule, boutonMenu, appliquerVitesse, attenteTour,
                        indicationAngle, indicationVitesse, saisieAngle, saisieVitesse,
                        visualiserAngle, visualiserVitesse, vitesseActuelle);
        
        menuJouer = new Scene(paneJouer, 1250, 725);
        
        boutonMenu.setOnAction((ActionEvent e) -> {
            MenuPrincipal menuPrincipal = new MenuPrincipal(superBillard);
            superBillard.setScene(menuPrincipal.getMenu());
            superBillard.centerOnScreen();

        });
        
        Image imageFond = new Image("Feutre.jpg", true);
        BackgroundImage fond = new BackgroundImage(imageFond, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        paneJouer.setBackground(new Background(fond));
    }
    
    public Scene getMenu() {
        return menuJouer;
    }
}
