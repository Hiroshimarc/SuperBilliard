/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

/**
 *
 * @author usager
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import static javafx.application.Application.launch;
import Vue.MenuPrincipal;
import javafx.scene.image.Image;

public class Launcher extends Application {

    Stage superBillard;
    Scene menuPrincipal;

    @Override
    public void start(Stage stage) throws Exception {

        this.superBillard = stage;

        MenuPrincipal unMenu = new MenuPrincipal(superBillard);
        menuPrincipal = unMenu.getMenu();

        superBillard.setResizable(false);
        superBillard.centerOnScreen();


        Image icone = new Image("Icone.png");
        superBillard.getIcons().add(icone);

        stage.setTitle("Super Billard");
        stage.setScene(menuPrincipal);
        stage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }
}
