package modele;

import javafx.scene.paint.Color;

/**Classe représentant la balle huit dans un ensemble de balles au billard
 * 2017-02-28
 * @author Vittorio Passuello-Dussault
 * @see Balle
 * @version 1.0
 */
public class BalleHuit extends Balle{
    /**Constructeur avec paramètres de la BalleHuit
     * 
     * @param rayon Rayon de la BalleHuit
     * @param surfaceDeJeu Objet Table représentant la table de billard
     */
    public BalleHuit(double rayon,Table surfaceDeJeu){
       this.setPositionInitialeX(2.295*surfaceDeJeu.getBoundsInLocal().getWidth()/3);
       this.setPositionInitialeY(surfaceDeJeu.getBoundsInLocal().getHeight()/2);
       this.setCouleur(Color.BLACK);
       this.setEnMouvement(false);
       this.setRayon(rayon);
    }
    
    /**Constructeur par défaut de la BalleHuit
     * 
     */
    public BalleHuit(){
        
    }
}
