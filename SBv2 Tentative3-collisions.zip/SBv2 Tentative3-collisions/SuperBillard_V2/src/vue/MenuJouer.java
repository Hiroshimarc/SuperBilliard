/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import Modèle.Balle;
import Modèle.EnsembleDeBalles;
import Modèle.Table;
import Modèle.VitesseHorsLimiteException;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author usager
 */
public class MenuJouer{

    Pane paneJouer;
    Scene menuJouer;
    Button boutonMenu;
    Stage superBillard;
    Table table;
    //Balle balle;
    Label indicationVitesse;
    Label vitesseActuelle;
    Slider saisieVitesse;
    Label indicationAngle;
    public static Label attenteTour;
    public static TextField saisieAngle;
    public static TextField visualiserVitesse;
    public static Button appliquerVitesse, visualiserAngle;
    Rectangle graduationG;
    Rectangle graduationY;
    Rectangle graduationR;
    Line visualisation;
    boolean alreadyDrawnDirectionLine = false; // Si une ligne indicatrice est déj<a tracée
    
    
    public MenuJouer(Stage stage) {
        superBillard = stage;
        paneJouer = new Pane();
        table = new Table(10, 10, 1000, 500, Color.GREEN, Color.BROWN, Color.rgb(128, 0, 0));
        menuJouer = new Scene(table, 1000, 500);
        
        boutonMenu = new Button("Revenir au menu Principal");
        boutonMenu.setLayoutX(1070);
        boutonMenu.setLayoutY(525);
        
        appliquerVitesse= new Button("GO!");
        appliquerVitesse.setMaxSize(50, 50);
        appliquerVitesse.setLayoutX(1120);
        appliquerVitesse.setLayoutY(300);
        
        visualiserAngle = new Button ("Visualiser");
        visualiserAngle.setMaxSize(100, 100);
        visualiserAngle.setLayoutX(1105);
        visualiserAngle.setLayoutY(270);
        
        indicationVitesse = new Label("Vitesse:");
        indicationVitesse.setMaxSize(150, 30);
        indicationVitesse.setLayoutX(1070);
        indicationVitesse.setLayoutY(80);
        
        attenteTour = new Label("Veuillez attendre la fin du tour");
        attenteTour.setMaxSize(200,40);
        attenteTour.setLayoutX(1070);
        attenteTour.setLayoutY(320);
        
        vitesseActuelle = new Label("Vitesse actuelle");
        vitesseActuelle.setMaxSize(200, 40);
        vitesseActuelle.setLayoutX(1070);
        vitesseActuelle.setLayoutY(340);
        
        
        saisieVitesse = new Slider();
        saisieVitesse.setMaxSize(150,30);
        saisieVitesse.setLayoutX(1070);
        saisieVitesse.setLayoutY(120);
        saisieVitesse.setMin(0);
        saisieVitesse.setMax(4);
        
        indicationAngle = new Label("Angle:");
        indicationAngle.setMaxSize(150, 30);
        indicationAngle.setLayoutX(1070);
        indicationAngle.setLayoutY(180);
        
        saisieAngle = new TextField("");
        saisieAngle.setMaxSize(150,30);
        saisieAngle.setLayoutX(1070);
        saisieAngle.setLayoutY(210);
        
        visualiserVitesse = new TextField("");
        visualiserVitesse.setMaxSize(150,30);
        visualiserVitesse.setLayoutX(1070);
        visualiserVitesse.setLayoutY(360);
        visualiserVitesse.setEditable(false);
        
        graduationG = new Rectangle(1070, 120, 50, 15);
        graduationG.setFill(Color.GREEN);
        graduationY = new Rectangle(1120, 120, 50, 15);
        graduationY.setFill(Color.YELLOW);
        graduationR = new Rectangle(1170, 120, 50, 15);
        graduationR.setFill(Color.RED);
        
        EnsembleDeBalles players = new EnsembleDeBalles(table);
        
        players.initialiserBalles(table);
        paneJouer.getChildren().add(table);
        paneJouer.getChildren().add(boutonMenu);
        paneJouer.getChildren().add(appliquerVitesse);
        paneJouer.getChildren().add(visualiserAngle);
        paneJouer.getChildren().add(graduationG);
        paneJouer.getChildren().add(graduationY);
        paneJouer.getChildren().add(graduationR);
        paneJouer.getChildren().add(indicationVitesse);
        paneJouer.getChildren().add(saisieVitesse);
        paneJouer.getChildren().add(indicationAngle);
        paneJouer.getChildren().add(saisieAngle);
        paneJouer.getChildren().add(attenteTour);
        paneJouer.getChildren().add(vitesseActuelle);
        paneJouer.getChildren().add(visualiserVitesse);
        attenteTour.setVisible(false);
        
        
        
        boutonMenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {

                paneJouer.getChildren().clear();
                MenuPrincipal menuPrincipal = new MenuPrincipal(superBillard);
                superBillard.setScene(menuPrincipal.menuPrincipal);

            }
        }
        );
        
        
        visualiserAngle.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                String validAngleFormat = acceptedSeparator(saisieAngle.getText());
                double angle = Double.parseDouble(validAngleFormat); 
                //Appel de méthode pour dessiner la ligne
                drawDirectionLine(players.balles.get(0), angle, table);
                
                
            }
        });
        
        appliquerVitesse.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                table.getChildren().remove(visualisation);
                String validAngleFormat = acceptedSeparator(saisieAngle.getText());
                double angle = Double.parseDouble(validAngleFormat);
                //On demande la saisie de la vitesse qui sera considérée comme une vitesse en m/s
                try{
                    double vitesse = saisieVitesse.getValue();
                    if(vitesse<=4 && vitesse>=0){
                        players.effectuerTour(players.balles.get(0).angleDeTir(angle),players.balles.get(0).obtenirVitesseLancement(vitesse),table); 
                    }else{
                        throw new VitesseHorsLimiteException("veuillez entrer une vitesse comprise entre ");
                    }
                }catch(VitesseHorsLimiteException vhle){
                    JOptionPane.showMessageDialog(null, vhle.getMessage()+vhle.vitesseMinimale+" m/s et "+vhle.vitesseMaximale+" m/s");
                    paneJouer.getChildren().clear();
                    MenuPrincipal menuPrincipal = new MenuPrincipal(superBillard);
                    superBillard.setScene(menuPrincipal.menuPrincipal);
                }

            }
        }
        );

    }
    
    /**Méthode qui permet de corriger une erreur courante lors de la saisie des nombres à décimales (remplace les virgules et les momayyez par des points pour assurer un bon fonctionnement du code)
     * @author Vittorio Passuello-Dussault
     * @param angleInput
     * @return acceptedFormat (valeur booléenne qui indique si le format de saisie est acceptable)
     * Source des séparateurs mondiaux : https://fr.wikipedia.org/wiki/S%C3%A9parateur_d%C3%A9cimal
     */
    public String acceptedSeparator(String angleInput){
        final char possibleSeparator1 = ',', possibleSeparator2='٫', separator='.';
        StringBuilder correct = new StringBuilder(angleInput);
        for (int count = 0; count<angleInput.length(); count++) {
            switch (angleInput.charAt(count)) {
                case possibleSeparator1:
                    correct.setCharAt(count, separator);
                case possibleSeparator2:
                    correct.setCharAt(count, separator);
            }
        }
        return correct.toString();
    }
    
    
    /**Méthode qui permet de tracer la ligne de direction
     * 
     */
    public void drawDirectionLine(Balle balle, double angle, Table table){
        if(alreadyDrawnDirectionLine){
            table.getChildren().remove(visualisation);
            alreadyDrawnDirectionLine = false;
        }
        angle = angle-270;
        angle = Math.toRadians(angle);
        
        //Distance entre la balle et le côté droit de la table
        double dbr = table.getBoundsInLocal().getMaxX()-342;
        //Distance entre la balle et le côté gauche de la table
        double dbl = table.getBoundsInLocal().getMinX()+303;
        //Distance entre la balle et le haut de la table
        //double dbu = 
        
        
        //Les points de débuts de la ligne sont les coordonnées de la balle
        double startX = balle.getLayoutX();
        double startY = balle.getLayoutY();
        
        //Calcul de l'hypothénuse
        System.out.println("Table   "+table.getBoundsInLocal().getMinX());
        System.out.println("Balle    "+balle.getBoundsInLocal().getMinX());
       
        //Calcul de la coordonnée finale en X avec hypothénuse arbitraire
        double endX = startX + dbl*(Math.sin(angle));
        double endY = startY + dbl*(Math.cos(angle));
        //Création de la Line
        visualisation = new Line(startX,startY,endX,endY);
        visualisation.setFill(Color.WHITE);
        visualisation.setStroke(Color.WHITE);
        table.getChildren().add(visualisation);
        alreadyDrawnDirectionLine = true;
        
        
    }

}

