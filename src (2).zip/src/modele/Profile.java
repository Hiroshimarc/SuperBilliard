/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.stage.FileChooser;
import vue.MenuPrincipal;
import controleur.Launcher;
import javafx.stage.Stage;

/**
 *
 * @author Édouard Raffis
 */
public class Profile {

    private final String nom;
    private final int nbCoup;
    private final int balleEmpochees;
    private final int nbVictoire;
    private final int nbPartieJouees;
    Stage superbillard = new Stage();

    public Profile(String nom) {
        this.nom = nom;
        nbCoup = 0;
        balleEmpochees = 0;
        nbVictoire = 0;
        nbPartieJouees = 0;

    }

    public String getNom() {
        return this.nom;
    }

    public String getStatistiques(String nom) {
        return compilateur();
    }

    private String compilateur() {
        String statistiques = "";
        statistiques
                = "Nombre de coup : " + nbCoup
                + "\nNombre de balle empochées : " + balleEmpochees
                + "\nNombre de parties jouées : " + nbPartieJouees
                + "\nNombre de victoire : " + nbVictoire;
        return statistiques;
    }
    /*
    public void saveFile() throws IOException {
        FileChooser fileChooser = new FileChooser();
        //Set extension filter
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
        fileChooser.getExtensionFilters().add(extFilter);

        //Show save file dialog
        File file = fileChooser.showSaveDialog(primaryStage);

        if (file != null) {
            SaveFile(compilateur(), file);
        }

        
    }

    private void SaveFile(String content, File file) {
        try {
            FileWriter fileWriter = null;

            fileWriter = new FileWriter(file);
            fileWriter.write(content);
            fileWriter.close();

        } catch (IOException ex) {
            Logger.getLogger(MenuPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }

    }*/
}
